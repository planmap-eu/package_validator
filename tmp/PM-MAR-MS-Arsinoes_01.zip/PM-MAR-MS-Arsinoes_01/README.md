---

![Browse](./document/PM-MAR-MS-Arsinoes_01.browse.png =800x*)

| Field                                                        | Description                                                  |
| ------------------------------------------------------------ | ------------------------------------------------------------ |
| Map name (PM_ID)                                             | PM-MAR-MS-Arsinoes_01                                        |
| Target body                                                  | Mars                                                         |
| Title of map                                                 | Geological Map of Arsinoes and Pyrrhae Chaos, Mars           |
| Bounding box - Min Lat                                       | -12                                                          |
| Bounding box - Max Lat                                       | -5.8                                                         |
| Bounding box - Min Lon (0-360)                               | 329.7                                                        |
| Bounding box - Max Lon (0-360)                               | 334.5                                                        |
| Author(s)                                                    | E. Luzzi, A.P. Rossi                                         |
| Type                                                         | Preliminary                                                  |
| Output scale                                                 | 1:3.000.000                                                  |
| Original Coordinate Reference System                         | Projected Coordinate System: Equirectangular Projection: Plate_Carree false_easting: 0.00000000 false_northing: 0.00000000 central_meridian: 0.00000000 Linear Unit: Meter Geographic Coordinate System: GCS_Geographic_Coordinate_System Datum: D_MARS Prime Meridian: Reference Meridian Angular Unit: Degree |
| Data used                                                    | MOLA Elevation Model MEGDR (463 m/pixel)CTX mosaic by MurrayLabCTX DTM (18 m)HiRISE RED (0,25 m/pixel) |
| Standards adhered to                                         | Planmap mapping standards document                           |
| DOI                                                          |                                                              |
| Aims (one sentence)                                          | Morpho-stratigraphic mapping                                 |
| Short description                                            | This map shows the contacts between the disrupted bedrock of the Chaotic terrain Units and the overlying sedimentary units. In addition, it shows the distribution of the graben/fissures and pit chains that are probably related to an intense past of magmatic activity and calderic collapse. In order to better characterize the mineralogical characteristics of the occurring deposits, also spectral analyses were tried out on the only available CRISM cube in the area (still in progress) |
| Related products (cross link to other Planmap products)      |                                                              |
| Units Definition                                             | Post-collapse craters, PCC, 51-160-44Cap Unit, CAP, 182-162-255Light-toned Layered deposits units, LLD, 77-205-255High Thermal Inertia Chaotic terrain, ChH, 227-28-28Knobby Terrain, ChK, 255-127-0Fractured Plains, ChF, 255-238-3 |
| Stratigraphic info (e.g. production function used)           | N/A                                                          |
| Other comments (reviewer comments, notes on post-processing) |                                                              |
| Heritage used                                                | Glotch and Christensen 2005                                  |
| Link to other repositories                                   |                                                              |
| Acknowledgements beyond Planmap                              | N/A                                                          |
